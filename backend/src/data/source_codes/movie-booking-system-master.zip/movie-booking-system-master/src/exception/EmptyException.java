package exception;

@SuppressWarnings("serial")
public class EmptyException extends Exception{
	public EmptyException(){
		super();
	}
}
