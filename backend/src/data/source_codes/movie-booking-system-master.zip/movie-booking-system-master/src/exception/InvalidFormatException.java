package exception;

@SuppressWarnings("serial")
public class InvalidFormatException extends Exception{
	public InvalidFormatException(){
		super();
	}
}
