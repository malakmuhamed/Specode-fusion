package exception;

public class MailSenderException extends Exception {

	public MailSenderException() {
		// TODO Auto-generated constructor stub
	}

	public MailSenderException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
