package exception;

@SuppressWarnings("serial")
public class DataSourceException extends Exception {
	
	public DataSourceException(){
		super();
	}

}
