package exception;

public class ServiceLocatorException extends Exception {
	
	public ServiceLocatorException(){
		super();
	}

	public ServiceLocatorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ServiceLocatorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
