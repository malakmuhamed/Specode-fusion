package model;

import java.util.ArrayList;

public class UserList extends ArrayList<User> {

}
