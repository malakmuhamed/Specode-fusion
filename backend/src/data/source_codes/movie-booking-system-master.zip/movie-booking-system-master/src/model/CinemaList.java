package model;

import java.util.ArrayList;

public class CinemaList extends ArrayList<Cinema> {

}
