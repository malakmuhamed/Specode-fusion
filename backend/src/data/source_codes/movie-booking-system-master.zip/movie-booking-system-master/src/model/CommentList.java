package model;

import java.util.ArrayList;

public class CommentList extends ArrayList<Comment> {

}
