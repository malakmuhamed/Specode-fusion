package model;

public abstract class BaseMode {

}
