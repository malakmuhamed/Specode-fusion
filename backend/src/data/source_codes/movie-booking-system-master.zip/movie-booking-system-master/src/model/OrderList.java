package model;

import java.util.ArrayList;

public class OrderList extends ArrayList<Order> {

}
